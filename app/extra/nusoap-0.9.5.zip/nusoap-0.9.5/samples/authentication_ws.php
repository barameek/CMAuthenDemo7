<?php
require_once('../lib/nusoap.php'); 
// Create the server instance
$server = new soap_server();
// Initialize WSDL support
$server->configureWSDL('authenwsdl', 'urn:authenwsdl');
// Register the method to expose
$server->register('authen',               // method name
    array('name' => 'xsd:string',
          'pass' => 'xsd:string'),        // input parameters
    array('return' => 'xsd:string'),      // output parameters
    'urn:authenwsdl',                     // namespace
    'urn:authenwsdl#authen',              // soapaction
    'rpc',                                // style
    'encoded',                            // use
    'authentication webservice demo'      // documentation
);
// Define the method as a PHP function

function authen($name, $pass) {
    if ($name == "admin" && $pass == "password"){
      return 'access granted';
	}else{
	  return "access denied";
	}
}
// Use the request to (try to) invoke the service
$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);
?>
